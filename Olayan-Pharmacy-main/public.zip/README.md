1-install packages
npm install

2-run the project
npm run dev


routes

