var API_URL = 'http://127.0.0.1:5000';

export const new_patient = async (username, password, name, email, dob, gender, num, ec) => {

    await fetch(API_URL + '/register/newPatient', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username,
            password,
            name,
            email,
            date_of_birth: dob,
            gender,
            mobile_number: num,
            emergency_contact: ec
        })
    })
}

export const new_doctor = async (username, password, name, email, dob, rate, hospital, edu) => {
    await fetch(API_URL + '/register/newDoctor', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username,
            password,
            name,
            email,
            date_of_birth: dob,
            hourly_rate: rate,
            affiliated_hospital: hospital,
            educational_background: edu
        })
    })
}

export const update_doctor = async (id, email, rate, hospital) => {
    await fetch(API_URL + `/doctor/${id}/updateInfo`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email,
            hourly_rate: rate,
            affiliated_hospital: hospital,
        })
    })
}


export const get_admin_data = async () => {
    return await fetch(API_URL + '/admin', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
}

export const accept_doctor = async (id) => {
    await fetch(API_URL + `/admin/acceptDoctor/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },

    })
}


export const remove_user = async (id) => {
    await fetch(API_URL + `/admin/removeUser/${id}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
    })
}


export const new_admin = async (username, password) => {
    await fetch(API_URL + '/admin/newAdmin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username,
            password
        })
    })
}



//////////////////////////  packages  //////////////////////////
export const get_packages = async () => {
    return await fetch(API_URL + '/admin/packages', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
}

export const update_package = async (id, name, price, doctor_sessions_discount, medicin_discount, subscriptions_discount) => {
    await fetch(API_URL + `/admin/updatePackage/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            price,
            doctor_sessions_discount,
            medicin_discount,
            subscriptions_discount
        })
    })
}

export const add_new_package = async (name, price, doctor_sessions_discount, medicine_discount, subscriptions_discount) => {
    await fetch(API_URL + `/admin/newPackage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            price,
            doctor_sessions_discount,
            medicine_discount,
            subscriptions_discount
        })
    })
}

export const delete_package = async (id) => {
    await fetch(API_URL + `/admin/removePackage/${id}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
    })
}


export const get_family_members = async (patient_id) => {
    return await fetch(API_URL + `/patient/${patient_id}/familyMembers`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })

}


export const get_patient_appointments = async (patient_id) => {
    return await fetch(API_URL + `/patient/${patient_id}/appointments`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })

}

export const add_family_member = async (
    patient_id,
    name,
    age,
    NID,
    gender,
    relation
) => {
    console.log("in api");
    console.log(patient_id);
    console.log(name);
    console.log(age);
    console.log(NID);

    const res = await fetch(API_URL + `/patient/${patient_id}/addFamilyMember`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            name,
            age,
            gender,
            national_id: NID,
            relation,
        }),
    });
};

export const get_doctor_appointment = async (i) => {
    const res = await fetch(API_URL + `/doctor/${i}/appointments`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    });
    return res.json();
}
