import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import NewPatient from "./pages/NewPatient.jsx";
import NewDoctor from "./pages/NewDoctor.jsx";
import NewAdmin from "./pages/NewAdmin.jsx";
import Admin from "./pages/Admin.jsx";
import NewPackage from "./pages/NewPackage.jsx";
import Packages from "./pages/Packages.jsx";
import Patients from "./pages/Patients.jsx";
import ViewDoctors from "./pages/ViewDoctors.jsx";
import Doctor from "./pages/Doctor.jsx";
import "./App.css";
import GetDoctors from "./pages/getDoctors.jsx";
import { ThemeProvider } from "@mui/material";
import "typeface-poppins";
import { Routes, Route, Link, BrowserRouter } from "react-router-dom";

import theme from "./theme.js";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <ThemeProvider theme={theme}>
        <div className="navbar flex flex-col h-screen  w-96 fixed z-50 ">
          <div className="name flex w-full justify-center">
            <h1 className="text-5xl font-extrabold w-56 mt-12 -mb-24 text-teal-500">
              3olyan clinic
            </h1>
          </div>
          <div className="main flex flex-col bg-teal-500 ml-10 shadow-2xl w-56 my-auto rounded-2xl py-8">
            <Link to="/register/newPatient" className="text-white mx-12 my-2">
              New Patient
            </Link>
            <Link to="/register/newDoctor" className="text-white mx-12 my-2">
              New Doctor
            </Link>
            <Link to="/admin" className="text-white mx-12 my-2">
              Admin
            </Link>
            <Link to="/admin/newAdmin" className="text-white mx-12 my-2">
              New Admin
            </Link>
            <Link to="/newPackage" className="text-white mx-12 my-2">
              New Package
            </Link>
            <Link to="/packages" className="text-white mx-12 my-2">
              Packages
            </Link>
            <Link to="/patients" className="text-white mx-12 my-2">
              Patients
            </Link>
            <Link to="/doctor" className="text-white mx-12 my-2">
              Doctor
            </Link>
            <Link to="/viewDoctors" className="text-white mx-12 my-2">
              View Appointments
            </Link>
            <Link to="/filterDoctors" className="text-white mx-12 my-2">
              filter doctors
            </Link>
          </div>
        </div>
      </ThemeProvider>
      <div className="body flex w-full pl-80 pr-12">
        <Routes>
          <Route path="/register/newPatient" element={<NewPatient />} />
          <Route path="/register/newDoctor" element={<NewDoctor />} />
          <Route path="/admin/newAdmin" element={<NewAdmin />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/newPackage" element={<NewPackage />} />
          <Route path="/packages" element={<Packages />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/viewDoctors" element={<ViewDoctors />} />
          <Route path="/doctor" element={<Doctor />} />
          <Route path="/filterDoctors" element={<GetDoctors />} />

          <Route path="/" element={<App />} />
        </Routes>
      </div>
    </BrowserRouter>
  </React.StrictMode>
);
