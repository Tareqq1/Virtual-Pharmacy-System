import { useState } from "react";
import {
  Button,
  Card,
  TextField,
  Select,
  MenuItem,
  Modal,
  Box,
} from "@mui/material";
import { update_doctor } from "../API";

import { HiX } from "react-icons/hi";

//username
//password
// name,
// email,
// date_of_birth,
// hourly_rate,
// affiliated_hospital, string
// educational_background, string

function UpdateDoctor({ doctor, open, setOpen }) {
  const [email, setEmail] = useState(doctor.email);
  const [hourly_rate, setHourly_rate] = useState(doctor.hourly_rate);
  const [affiliated_hospital, setAffiliated_hospital] = useState(
    doctor.affiliated_hospital
  );

  console.log(doctor)

  const handleSubmit = async () => {
    const res = await update_doctor(
      doctor._id,
      email,
      hourly_rate,
      affiliated_hospital
    );
    console.log(res);
  };

  const handleClose = () => setOpen(false);
  const handleOpen = () => setOpen(true);

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card className="flex flex-col bg-white gap-4 m-12 p-12 rounded-2xl">
          <div className="ml-auto -mt-6">
            <HiX size={25} onClick={handleClose} className="cursor-pointer" />
          </div>
          <TextField
            id="outlined-basic"
            label="email"
            variant="outlined"
            onChange={(e) => setEmail(e.target.value)}
            defaultValue={doctor.email}
          />

          <TextField
            id="outlined-basic"
            label="hourly rate"
            variant="outlined"
            onChange={(e) => setHourly_rate(e.target.value)}
            defaultValue={doctor.hourly_rate}
          />
          <TextField
            id="outlined-basic"
            label="affiliated hospital"
            variant="outlined"
            onChange={(e) => setAffiliated_hospital(e.target.value)}
            defaultValue={doctor.affiliated_hospital}
          />

          <Button variant="contained" onClick={handleSubmit}>
            Update
          </Button>
        </Card>
      </Modal>
    </>
  );
}

export default UpdateDoctor;
