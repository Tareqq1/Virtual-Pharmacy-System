import { useEffect, useState } from "react";

import { get_admin_data, remove_user, accept_doctor } from "../API";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";

function GetDoctors() {
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    const res = get_admin_data()
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data);
        for (let i = 0; i < data.accepted_doctors.length; i++) {
          data.accepted_doctors[i].id = i;
          data.accepted_doctors[i].name = data.accepted_doctors[i].doctor.name;
          data.accepted_doctors[i].speciality =
            data.accepted_doctors[i].doctor.speciality;
          data.accepted_doctors[i].hourly_rate =
            data.accepted_doctors[i].doctor.hourly_rate;
        }

        setDoctors(data.accepted_doctors);
        console.log(doctors);
      });
  }, []);

  const columns = ["name", "speciality", "hourly_rate"].map((col) => ({
    field: col,
    headerName: col,
    width: 200,
  }));

  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const nameSearch = doctors.filter((doctor) =>
      doctor.name.toLowerCase().includes(searchTerm)
    );

    const specialitySearch = doctors.filter((doctor) =>
      doctor.speciality.toLowerCase().includes(searchTerm)
    );

    const results = [...nameSearch, ...specialitySearch];

    setDoctors(results);
  }, [searchTerm]);

  return (
    <>
      <div style={{ height: 400, width: "100%" }}>
        <DataGrid
          className="w-full h-80"
          rows={doctors}
          columns={columns}
          pageSize={5}
          checkboxSelection
        />
      </div>
    </>
  );
}

export default GetDoctors;
