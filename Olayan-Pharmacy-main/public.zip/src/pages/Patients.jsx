import { useEffect, useState } from "react";
import { FcAbout } from "react-icons/fc";
import {
  Button,
  Card,
  TextField,
  Select,
  MenuItem,
  Modal,
} from "@mui/material";

import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import {
  get_admin_data,
  remove_user,
  accept_doctor,
  get_family_members,
  get_patient_appointments,
  add_family_member,
} from "../API";
import {
  HiTrash,
  HiCheck,
  HiPencil,
  HiPlus,
  HiClipboard,
} from "react-icons/hi";
import { HiX } from "react-icons/hi";


function Admin() {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    const res = get_admin_data()
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data.all_patients);
        setPatients(data.all_patients);
        console.log(patients);
      });
  }, []);

  const [viewPatient, setViewPatient] = useState({});
  const [viewPatientOpen, setViewPatientOpen] = useState(false);
  const handleClose = () => {
    setViewPatientOpen(false);
  };

  const [familyMembers, setFamilyMembers] = useState([]);

  useEffect(() => {
    if (!viewPatientOpen) return;
    const res = get_family_members(viewPatient._id)
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data);
        setFamilyMembers(data);
      });
  }, [viewPatient]);

  const [appointments, setAppointments] = useState([{
    status: 'pending',
    time_slot: {
      start_time: '2021-10-20T11:00:00.000Z',
      end_time: '2021-10-20T11:30:00.000Z',
    }
  }]);

  useEffect(() => {
    if (!viewPatientOpen) return;
    const res = get_patient_appointments(viewPatient._id).then((res) => {
      if (res.status === 200) {
        return res.json();
      }
    }
    ).then((data) => {
      console.log(data);
      setAppointments(data);
    })

  }, [viewPatient]);

  const [name, setName] = useState("");
  const [NID, setNID] = useState("");
  const [gender, setGender] = useState("");
  const [age, setAge] = useState("");
  const [relation, setRelation] = useState("");

  const [choosenFamily, setChoosenFamily] = useState({
    _id: 0,
    name: "",
    age: "",
    gender: "",
    NID: "",
    relation: "",
  });
  const [choosenFamilyRelation, setChoosenFamilyRelation] = useState("");
  return (
    <>
      <Modal
        open={viewPatientOpen}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
        style={{ overflow: "auto" }}
      >
        <Card className="flex flex-col bg-white gap-4 m-12 p-12 rounded-2xl overflow-scroll">
          <div className="ml-auto -mt-6">
            <HiX size={25} onClick={handleClose} className="cursor-pointer" />
          </div>
          <Select
            id="select-fam"
            variant="outlined"
            onChange={(e) => {
              setChoosenFamily(e.target.value);
            }}
          >
            {patients.map((patient) => {
              return (
                <MenuItem key={patient.patient._id} value={patient.patient}>
                  <div className="item">
                    <p>email {patient.patient.email}</p>
                    <p>phone {patient.patient.mobile_number}</p>
                  </div>
                </MenuItem>
              );
            })}
          </Select>
          <Select
            variant="outlined"
            onChange={(e) => setChoosenFamilyRelation(e.target.value)}
          >
            <MenuItem value="husband">Husband</MenuItem>
            <MenuItem value="wife">Wife</MenuItem>
            <MenuItem value="child">Child</MenuItem>
          </Select>

          <Button
            variant="contained"
            onClick={() => {
              add_family_member(
                choosenFamily._id,
                choosenFamily.name,
                2021 - new Date(choosenFamily.date_of_birth).getFullYear(),
                "23123123132213",
                choosenFamily.gender,
                choosenFamilyRelation
              );
            }}
          >
            Add
          </Button>
          {/* add member */}
          <div className="flex flex-col gap-4">
            <h1 className="text-2xl font-bold">Add Member</h1>
            <div className="flex flex-col gap-4">
              <TextField
                variant="outlined"
                label="Name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              <TextField
                variant="outlined"
                label="National ID"
                value={NID}
                onChange={(e) => {
                  setNID(e.target.value);
                }}
              />
              <TextField
                variant="outlined"
                label="Age"
                value={age}
                onChange={(e) => {
                  setAge(e.target.value);
                }}
              />
              <Select
                id="outlined-basic"
                variant="outlined"
                onChange={(e) => setGender(e.target.value)}
              >
                <MenuItem value="male">Male</MenuItem>
                <MenuItem value="female">Female</MenuItem>
              </Select>

              <Select
                variant="outlined"
                onChange={(e) => setRelation(e.target.value)}
              >
                <MenuItem value="husband">Husband</MenuItem>
                <MenuItem value="wife">Wife</MenuItem>
                <MenuItem value="child">Child</MenuItem>
              </Select>
              <Button
                variant="contained"
                onClick={() => {
                  add_family_member(
                    viewPatient._id,
                    name,
                    age,
                    NID,
                    gender,
                    relation
                  );
                }}
              >
                Add
              </Button>
              <div className="family">
                <h1>Family</h1>
                {familyMembers.map((member) => {
                  return (
                    <div className="member flex flex-col gap-2 mb-8">
                      <h1 className="text-2xl font-bold">{member.name}</h1>
                      <h1>NID: {member.national_id}</h1>
                      <h1>Age: {member.age}</h1>
                      <h1>Gender: {member.gender}</h1>
                      <h1>Relation: {member.relation}</h1>
                      <h1 className="text-xl font-bold">appointments</h1>
                    </div>
                  );
                })}
              </div>

              <div className="appointments">
                <h1>Appointments</h1>
                {appointments.map((app) => {
                  return (
                    <div className="apps flex flex-col">
                      <h1>Start: {new Date(app.time_slot?.start_time).toLocaleString()}</h1>
                      <h1>End: {new Date(app.time_slot?.end_time).toLocaleString()}</h1>
                      <h1>Status: {app.status}</h1>
                    </div>
                  );
                })}
                
              </div>
            </div>
          </div>
        </Card>
      </Modal>

      <div className="mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">All Data</h1>
        <div className="card-container flex w-full justify-center flex-col">
          <Card className="p-8 mt-12 flex flex-col gap-4">
            <h1 className="text-2xl font-bold">Patients</h1>
            <div className="contauner ml-4">
              {patients.map((patient) => {
                return (
                  <div
                    key={patient._id}
                    className="element flex justify-between"
                  >
                    <h1>{patient.patient?.name}</h1>

                    <div className="actions flex gap-4">
                      <HiTrash
                        className="cursor-pointer ml-4"
                        onClick={() => {
                          remove_user(patient._id);
                        }}
                      />
                      <p
                        onClick={() => {
                          setViewPatient(patient.patient);
                          setViewPatientOpen(true);
                        }}
                        className="cursor-pointer text-blue-500"
                      >
                        view/edit
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}

export default Admin;
