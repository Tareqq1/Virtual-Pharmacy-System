import { useState } from "react";
import { FcAbout } from "react-icons/fc";
import { Button, Card, TextField, Select, MenuItem } from "@mui/material";
import { new_admin } from "../API";

//username
//password
// name,
// email,
// date_of_birth,
// hourly_rate,
// affiliated_hospital, string
// educational_background, string

function NewAdmin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async () => {
    const res = await new_admin(
      username,
      password,
    );
    console.log(res);
  };

  return (
    <>
      <div className=" mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">Register new admin</h1>
        <div className="card-container flex w-full justify-center">
          <Card className="p-8 mt-12 flex flex-col gap-4">
            <TextField
              id="outlined-basic"
              label="username"
              variant="outlined"
              onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="password"
              variant="outlined"
              type="password"
              onChange={(e) => setPassword(e.target.value)}
            />

            <Button variant="contained" onClick={handleSubmit}>
              Submit
            </Button>
          </Card>
        </div>
      </div>
    </>
  );
}

export default NewAdmin;
