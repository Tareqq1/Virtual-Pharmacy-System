import { useState, useEffect } from "react";
import { FcAbout } from "react-icons/fc";
import { Button, Card, TextField, Select, MenuItem } from "@mui/material";
import { HiTrash, HiCheck, HiPencil } from "react-icons/hi";
import UpdatePackage from "./UpdatePackage";
import {
  get_packages,
  update_package,
  delete_package,
  add_new_package,
} from "../API";

function Packages() {
  const [data, setData] = useState([]);

  const [updatePackageOpen, setUpdatePackageOpen] = useState(false);
  const [updatePackage, setUpdatePackage] = useState({
    name: "",
    price: "",
    doctor_sessions_discount: "",
    medicine_discount: "",
    subscriptions_discount: "",
  });

  useEffect(() => {
    const res = get_packages()
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data);
        setData(data);
      });
  }, []);

  return (
    <>
      <UpdatePackage
        pack={updatePackage}
        open={updatePackageOpen === true}
        setOpen={setUpdatePackageOpen}
      />
      <div className=" mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">Packages</h1>
        <div className="card-container flex w-full justify-center">
          {data.map((pack) => {
            return (
              <Card className="p-4 w-56" key={pack._id}>
                <div className="flex justify-between w-full mb-4">
                  <h1 className="text-2xl font-bold">{pack.name}</h1>
                  <div className="actions">
                    <HiPencil
                      onClick={() => {
                        setUpdatePackage(pack);
                        setUpdatePackageOpen(true);
                      }}
                      className="text-2xl text-green-500 mr-4 cursor-pointer"
                    />
                    <HiTrash
                      onClick={() => {
                        delete_package(pack._id);
                      }}
                      className="text-2xl text-red-500 cursor-pointer"
                    />
                  </div>
                </div>
                <h1>price {pack.price} LE</h1>
                <h1>doctor's discount {pack.doctor_sessions_discount} LE</h1>
                <h1>medicine discount {pack.medicine_discount} LE</h1>
                <h1>subscriptions discount {pack.subscriptions_discount} LE</h1>
              </Card>
            );
          })}
        </div>
      </div>
    </>
  );
}

export default Packages;
