import { useState } from "react";
import {
  Button,
  Card,
  TextField,
  Select,
  MenuItem,
  Modal,
  Box,
} from "@mui/material";
import { update_package } from "../API";

import { HiX } from "react-icons/hi";

function UpdatePackage({ pack, open, setOpen }) {
  const [name, setName] = useState(pack.name);
  const [price, setPrice] = useState(pack.price);
  const [doctor_sessions_discount, setDoctor_sessions_discount] = useState(
    pack.doctor_sessions_discount
  );
  const [medicine_discount, setMedicine_discount] = useState(
    pack.medicine_discount
  );
  const [subscriptions_discount, setSubscriptions_discount] = useState(
    pack.subscriptions_discount
  );

  console.log(pack);

  const handleSubmit = async () => {
    const res = await update_package(
      pack._id,
      name,
      price,
      doctor_sessions_discount,
      medicine_discount,
      subscriptions_discount
    );
    console.log(res);
  };

  const handleClose = () => setOpen(false);
  const handleOpen = () => setOpen(true);

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card className="flex flex-col bg-white gap-4 m-12 p-12 rounded-2xl">
          <div className="ml-auto -mt-6">
            <HiX size={25} onClick={handleClose} className="cursor-pointer" />
          </div>
          <TextField
            id="outlined-basic"
            label="name"
            variant="outlined"
            onChange={(e) => setName(e.target.value)}
            defaultValue={pack.name}
          />
          <TextField
            id="outlined-basic"
            label="price"
            variant="outlined"
            onChange={(e) => setPrice(e.target.value)}
            defaultValue={pack.price}
          />
          <TextField
            id="outlined-basic"
            label="doctor sessions discount"
            variant="outlined"
            onChange={(e) => setDoctor_sessions_discount(e.target.value)}
            defaultValue={pack.doctor_sessions_discount}
          />
          <TextField
            id="outlined-basic"
            label="medicine discount"
            variant="outlined"
            onChange={(e) => setMedicine_discount(e.target.value)}
            defaultValue={pack.medicine_discount}
          />
          <TextField
            id="outlined-basic"
            label="subscriptions discount"
            variant="outlined"
            onChange={(e) => setSubscriptions_discount(e.target.value)}
            defaultValue={pack.subscriptions_discount}
          />

          <Button variant="contained" onClick={handleSubmit}>
            Update
          </Button>
        </Card>
      </Modal>
    </>
  );
}

export default UpdatePackage;
