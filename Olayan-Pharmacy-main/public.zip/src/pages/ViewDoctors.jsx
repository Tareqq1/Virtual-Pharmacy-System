import { useEffect, useState } from "react";
import { FcAbout } from "react-icons/fc";
import {
  Button,
  Card,
  TextField,
  Select,
  MenuItem,
  Modal,
} from "@mui/material";
import {
  get_admin_data,
  get_doctor_appointment,
  get_patient_appointments,
} from "../API";
import { HiTrash, HiCheck, HiPencil } from "react-icons/hi";
import UpdateDoctor from "./UpdateDoctor";
import { DataGrid } from "@mui/x-data-grid";

function ViewDoctors() {
  const [admins, setAdmins] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [pending_doctors, setPending_doctors] = useState([]);
  const [apps, setApps] = useState([]);

  useEffect(() => {
    const res = get_admin_data()
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data);
        setAdmins(data.admins);
        setPatients(data.all_patients);
        setDoctors(data.accepted_doctors);
        setPending_doctors(data.pending_doctors);

        let appointments = [];

        // for (let i = 0; i < doctors.length; i++) {
        //   get_doctor_appointment(doctors[i].doctor._id)
        //     .then((res) => {
        //       if (res.status === 200) {
        //         return res.json();
        //       }
        //     })
        //     .then((data) => {
        //       const result = {
        //         id: data._id,
        //         start: data.time_slot.start_time,
        //         end: data.status.end_time,
        //         ...doctors[i],
        //         type: "doctor",
        //       };
        //       console.log(result);
        //       appointments.push(data);
        //       setApps(appointments);
        //     });
        // }

        for (let i = 0; i < patients.length; i++) {
          get_patient_appointments(patients[i].patient._id)
            .then((res) => {
              if (res.status === 200) {
                return res.json();
              }
            })
            .then((data) => {
              console.log(data);
              for (let k = 0; i < data.length; i++) {
                const result = {
                  id: Math.random() * 10000,
                  patient_name: patients[i].patient.name,
                  doctor_name: data[k].doctor.name,
                  start: new Date(data[k].time_slot.start_time).toLocaleString(),
                  end: new Date(data[k].time_slot.end_time).toLocaleString(),
                  status: data[k].status,
                };
                console.log(result);

                if (appointments.find((app) => app._id === result._id)) return;
                appointments.push(result);
                setApps([...appointments, ...apps]);
              }
            });
        }
      });
  }, []);

  console.log(apps);
 
  const columns = ["patient_name", "doctor_name", "start", "end", "status"].map(
    (col) => ({
      field: col,
      headerName: col,
      width: 200,
    })
  );

  return (
    <>
      <DataGrid
        className="w-full h-80"
        rows={apps}
        columns={columns}
        pageSize={5}
        checkboxSelection
      />
    </>
  );
}

export default ViewDoctors;
