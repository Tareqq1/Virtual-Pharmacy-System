import { useState } from "react";
import { FcAbout } from "react-icons/fc";
import { Button, Card, TextField, Select, MenuItem } from "@mui/material";
import { new_doctor } from "../API";

//username
//password
// name,
// email,
// date_of_birth,
// hourly_rate,
// affiliated_hospital, string
// educational_background, string

function NewDoctor() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [date_of_birth, setDate_of_birth] = useState("");
  const [hourly_rate, setHourly_rate] = useState("");
  const [affiliated_hospital, setAffiliated_hospital] = useState("");
  const [educational_background, setEducational_background] = useState("");

  const handleSubmit = async () => {
    const res = await new_doctor(
      username,
      password,
      name,
      email,
      date_of_birth,
      hourly_rate,
      affiliated_hospital,
      educational_background
    );
    console.log(res);
  };

  return (
    <>
      <div className=" mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">Register new doctor</h1>
        <div className="card-container flex w-full justify-center">
          <Card className="p-8 mt-12 flex flex-col gap-4">
            <TextField
              id="outlined-basic"
              label="username"
              variant="outlined"
              onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="password"
              variant="outlined"
              type="password"
              onChange={(e) => setPassword(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="name"
              variant="outlined"
              onChange={(e) => setName(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="email"
              variant="outlined"
              onChange={(e) => setEmail(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              variant="outlined"
              type="date"
              onChange={(e) => setDate_of_birth(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="hourly rate"
              variant="outlined"
              onChange={(e) => setHourly_rate(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="affiliated hospital"
              variant="outlined"
              onChange={(e) => setAffiliated_hospital(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="educational background"
              variant="outlined"
              onChange={(e) => setEducational_background(e.target.value)}
            />

            <Button variant="contained" onClick={handleSubmit}>
              Submit
            </Button>
          </Card>
        </div>
      </div>
    </>
  );
}

export default NewDoctor;
