import { useState } from "react";
import { FcAbout } from "react-icons/fc";
import { Button, Card, TextField, Select, MenuItem } from "@mui/material";
import { new_patient } from "../API";
// username,
// password,
// name,
// email,
// date_of_birth,
// gender,
// mobile_number,
// emergency_contact,

function NewPatient() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [date_of_birth, setDate_of_birth] = useState("");
  const [gender, setGender] = useState("");
  const [mobile_number, setMobile_number] = useState("");
  const [emergency_contact_name, setEmergency_contact_name] = useState("");
  const [emergency_contact_phone, setEmergency_contact_phone] = useState("");

  const handleSubmit = async () => {
    new_patient(
      username,
      password,
      name,
      email,
      date_of_birth,
      gender,
      mobile_number,
      { name: emergency_contact_name, mobile_number: emergency_contact_phone }
    );
  };

  return (
    <>
      <div className=" mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">Register new patient</h1>
        <div className="card-container flex w-full justify-center">
          <Card className="p-8 mt-12 flex flex-col gap-4">
            <TextField
              id="outlined-basic"
              label="username"
              variant="outlined"
              onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="password"
              variant="outlined"
              type="password"
              onChange={(e) => setPassword(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="name"
              variant="outlined"
              onChange={(e) => setName(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="email"
              variant="outlined"
              onChange={(e) => setEmail(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              variant="outlined"
              type="date"
              onChange={(e) => setDate_of_birth(e.target.value)}
            />
            <Select
              id="outlined-basic"
              variant="outlined"
              onChange={(e) => setGender(e.target.value)}
            >
              <MenuItem value="male">Male</MenuItem>
              <MenuItem value="female">Female</MenuItem>
            </Select>

            <TextField
              id="outlined-basic"
              label="mobile number"
              variant="outlined"
              onChange={(e) => setMobile_number(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="emergency contact name"
              variant="outlined"
              onChange={(e) => setEmergency_contact_name(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="emergency contact phone"
              variant="outlined"
              onChange={(e) => setEmergency_contact_phone(e.target.value)}
            />

            <Button variant="contained" onClick={handleSubmit}>
              Submit
            </Button>
          </Card>
        </div>
      </div>
    </>
  );
}

export default NewPatient;
