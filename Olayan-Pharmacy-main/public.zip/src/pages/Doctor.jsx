import { useEffect, useState } from "react";
import { FcAbout } from "react-icons/fc";
import {
  Button,
  Card,
  TextField,
  Select,
  MenuItem,
  Modal,
} from "@mui/material";
import { get_admin_data, remove_user, accept_doctor } from "../API";
import { HiTrash, HiCheck, HiPencil } from "react-icons/hi";
import UpdateDoctor from "./UpdateDoctor";

function Doctor() {
  const [admins, setAdmins] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [pending_doctors, setPending_doctors] = useState([]);

  useEffect(() => {
    const res = get_admin_data()
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log(data);
        setAdmins(data.admins);
        setPatients(data.all_patients);
        setDoctors(data.accepted_doctors);
        setPending_doctors(data.pending_doctors);
      });
  }, []);

  const [updateDoctor, setUpdateDoctor] = useState({
    username: "",
    password: "",
    name: "",
    email: "",
    date_of_birth: "",
    hourly_rate: "",
    affiliated_hospital: "",
    educational_background: "",
  });

  const [viewPendingDoctor, setViewPendingDoctor] = useState({});
  const [openPendingDoctor, setOpenPendingDoctor] = useState(false);

  const [updateDoctorOpen, setUpdateDoctorOpen] = useState(false);

  return (
    <>
      <UpdateDoctor
        doctor={updateDoctor}
        open={updateDoctorOpen === true}
        setOpen={setUpdateDoctorOpen}
      />

      <Card className="p-8 mt-12 flex flex-col gap-4">
        <h1 className="text-2xl font-bold">Doctors</h1>
        <div className="contauner ml-4">
          {doctors.map((doctor) => {
            return (
              <div key={doctor._id} className="element flex justify-between">
                <h1>{doctor.doctor?.name}</h1>{" "}
                <div className="actions flex gap-4">
                  <HiPencil
                    className="ml-4 cursor-pointer"
                    onClick={() => {
                      setUpdateDoctor(doctor);
                      setUpdateDoctorOpen(true);
                    }}
                  />
                  <HiTrash
                    onClick={() => {
                      remove_user(doctor._id);
                    }}
                    className="ml-4 cursor-pointer"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </>
  );
}

export default Doctor;
