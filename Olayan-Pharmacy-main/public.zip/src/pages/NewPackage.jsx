import { useState } from "react";
import { FcAbout } from "react-icons/fc";
import { Button, Card, TextField, Select, MenuItem } from "@mui/material";
import { add_new_package } from "../API";

// name, price, doctor_sessions_discount, medicin_discount, subscriptions_discount

function NewPackage() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [doctor_sessions_discount, setDoctor_sessions_discount] = useState("");
  const [medicine_discount, setMedicine_discount] = useState("");
  const [subscriptions_discount, setSubscriptions_discount] = useState("");

  const handleSubmit = async () => {
    add_new_package(
      name,
      price,
      doctor_sessions_discount,
      medicine_discount,
      subscriptions_discount
    );
  };

  return (
    <>
      <div className=" mt-12 w-full mb-12">
        <h1 className="flex font-extrabold text-2xl">Add a new package</h1>
        <div className="card-container flex w-full justify-center">
          <Card className="p-8 mt-12 flex flex-col gap-4">
            <TextField
              id="outlined-basic"
              label="name"
              variant="outlined"
              onChange={(e) => setName(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="price"
              variant="outlined"
              type="number"
              onChange={(e) => setPrice(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="doctor sessions discount"
              variant="outlined"
              onChange={(e) => setDoctor_sessions_discount(e.target.value)}
            />
            <TextField
              id="outlined-basic"
              label="medicine discount"
              variant="outlined"
              onChange={(e) => setMedicine_discount(e.target.value)}
            />

            <TextField
              id="outlined-basic"
              label="subscriptions discount"
              variant="outlined"
              onChange={(e) => setSubscriptions_discount(e.target.value)}
            />

            <Button variant="contained" onClick={handleSubmit}>
              Submit
            </Button>
          </Card>
        </div>
      </div>
    </>
  );
}

export default NewPackage;
